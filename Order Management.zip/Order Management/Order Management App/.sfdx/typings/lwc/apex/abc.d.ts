declare module "@salesforce/apex/abc.getProductList" {
  export default function getProductList(param: {searchKey: any, inSearch: any}): Promise<any>;
}
declare module "@salesforce/apex/abc.createOrder" {
  export default function createOrder(param: {selectedProducts: any, priceBookId: any, accId: any}): Promise<any>;
}
