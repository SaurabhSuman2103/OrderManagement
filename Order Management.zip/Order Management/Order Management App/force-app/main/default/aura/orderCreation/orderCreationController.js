({
    handleSuccess : function(component, event, helper) {
    var payload = event.getParams().response;
        console.log(payload.id);
    var navService = component.find("navService");
        console.log('qq');
    var pageReference = {
        type: 'standard__recordPage',
        attributes: {
            "recordId": payload.id,
            "objectApiName": "Order",
            "actionName": "view"
        }
    }
    event.preventDefault();
    navService.navigate(pageReference);  
    } ,
    searchKeyChange: function(component, event, helper) {
        var myEvent = $A.get("e.yournamespace:SearchKeyChange");
        myEvent.setParams({"searchKey": event.target.value});
        myEvent.fire();
    }
   
})